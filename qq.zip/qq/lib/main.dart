import 'package:flutter/material.dart';
import 'package:excel/excel.dart' hide Border;
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'نور القرآن',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0x0010B981),
          primary: const Color(0xFF10B981),
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          elevation: 0.5,
          scrolledUnderElevation: 0.5,
          surfaceTintColor: Colors.transparent,
          iconTheme: IconThemeData(color: Colors.black),
          titleTextStyle: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        scaffoldBackgroundColor: const Color(0xFFF3F4F6),
      ),
      home: const MyHomePage(title: 'نور القرآن'),
      locale: const Locale('ar', 'SA'),
      supportedLocales: const [Locale('ar', 'SA'), Locale('en', 'US')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<List<String>> _excelData = [];
  List<List<String>> _teacherData = [];
  bool _isLoading = true;
  String _errorMessage = '';
  int _activeMenuIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadExcelData();
  }

  Future<void> _loadExcelData() async {
    try {
      // قراءة ملف Excel من الأصول
      final data = await rootBundle.load('assets/Excel.xlsx');
      final bytes = data.buffer.asUint8List();
      
      // فك الضغط عن ملف Excel
      final excel = Excel.decodeBytes(bytes);
      
      List<List<String>> allData = [];
      
      // الحصول على البيانات من جميع الأوراق
      for (var table in excel.tables.keys) {
        final sheet = excel.tables[table];
        if (sheet != null) {
          for (var row in sheet.rows) {
            List<String> rowData = [];
            for (var cell in row) {
              rowData.add(cell?.value?.toString() ?? '');
            }
            if (rowData.any((cell) => cell.isNotEmpty)) {
              allData.add(rowData);
            }
          }
        }
      }
      
      // قراءة ملف teacher.xlsx
      final teacherDataRaw = await rootBundle.load('assets/teacher.xlsx');
      final teacherBytes = teacherDataRaw.buffer.asUint8List();
      
      final teacherExcel = Excel.decodeBytes(teacherBytes);
      
      List<List<String>> teacherDataList = [];
      
      // الحصول على بيانات الاساتذة
      for (var table in teacherExcel.tables.keys) {
        final sheet = teacherExcel.tables[table];
        if (sheet != null) {
          for (var row in sheet.rows) {
            List<String> rowData = [];
            for (var cell in row) {
              rowData.add(cell?.value?.toString() ?? '');
            }
            if (rowData.any((cell) => cell.isNotEmpty)) {
              teacherDataList.add(rowData);
            }
          }
        }
      }
      
      setState(() {
        _excelData = allData;
        _teacherData = teacherDataList;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'خطأ في تحميل الملف: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'نور القرآن',
          textDirection: TextDirection.rtl,
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: false,
        backgroundColor: Colors.white,
        elevation: 0.5,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.grey.withOpacity(0.1),
      ),
      drawer: _buildDrawer(),
      backgroundColor: const Color(0xFFF3F4F6),
      body: _buildBodyContent(),
    );
  }

  Widget _buildBodyContent() {
    if (_isLoading && _activeMenuIndex == 2) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage.isNotEmpty && _activeMenuIndex == 2) {
      return Center(
        child: Text(
          _errorMessage,
          style: const TextStyle(color: Colors.red, fontSize: 16),
          textAlign: TextAlign.center,
        ),
      );
    }

    switch (_activeMenuIndex) {
      case 0:
        // لوحة التحكم
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.dashboard,
                size: 80,
                color: Color(0xFF10B981),
              ),
              const SizedBox(height: 24),
              const Text(
                'مرحباً بك',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'في لوحة التحكم الرئيسية',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        );
      case 1:
        // الاساتذة
        return _teacherData.isEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.person,
                      size: 80,
                      color: Color(0xFF10B981),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'الاساتذة',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'لا توجد بيانات متاحة حالياً',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              )
            : _buildModernTable(_teacherData);
      case 2:
        // الطلبة - عرض بيانات Excel
        return _excelData.isEmpty
            ? const Center(child: Text('لا توجد بيانات في الملف'))
            : _buildModernTable(_excelData);
      default:
        return const Center(child: Text('صفحة غير معروفة'));
    }
  }



  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.white,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // الترويسة
          Container(
            color: const Color(0xFF10B981),
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // الشعار
                const Icon(
                  Icons.menu_book,
                  color: Colors.white,
                  size: 40,
                ),
                const SizedBox(height: 12),
                // العنوان
                const Text(
                  'نور القرآن',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                // العنوان الفرعي
                Text(
                  'نظام إدارة الحلقات',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.85),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          // التصنيف
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              'القائمة الرئيسية',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 12,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ),
          
          const SizedBox(height: 8),
          
          // عناصر التنقل
          _buildNavItem(
            title: 'لوحة التحكم',
            icon: Icons.dashboard,
            index: 0,
            isActive: _activeMenuIndex == 0,
          ),
          
          _buildNavItem(
            title: 'الاساتذة',
            icon: Icons.person,
            index: 1,
            isActive: _activeMenuIndex == 1,
          ),
          
          _buildNavItem(
            title: 'الطلبة',
            icon: Icons.people,
            index: 2,
            isActive: _activeMenuIndex == 2,
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem({
    required String title,
    required IconData icon,
    required int index,
    required bool isActive,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Material(
        color: isActive ? const Color(0xFF10B981) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        child: InkWell(
          onTap: () {
            setState(() {
              _activeMenuIndex = index;
            });
            Navigator.pop(context);
          },
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              textDirection: TextDirection.rtl,
              children: [
                Icon(
                  icon,
                  color: isActive ? Colors.white : Colors.grey[600],
                  size: 20,
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: isActive ? Colors.white : Colors.grey[700],
                    fontSize: 14,
                    fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModernTable(List<List<String>> data) {
    if (data.isEmpty) {
      return const Center(child: Text('لا توجد بيانات'));
    }

    // الصف الأول هو رأس الجدول
    final headerRow = data[0];
    final bodyRows = data.sublist(1);

    return Container(
      color: const Color(0xFFF3F4F6),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Column(
            children: [
              // رأس الجدول
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF10B981),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                  ),
                ),
                child: Row(
                  children: List.generate(
                    headerRow.length,
                    (colIndex) => Container(
                      width: 120,
                      padding: const EdgeInsets.all(16),
                      alignment: Alignment.center,
                      child: Text(
                        headerRow[colIndex],
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ),
              ),
              // صفوف البيانات
              ...List.generate(
                bodyRows.length,
                (rowIndex) {
                  final isEven = rowIndex % 2 == 0;
                  final isLastRow = rowIndex == bodyRows.length - 1;
                  
                  return Container(
                    decoration: BoxDecoration(
                      color: isEven ? Colors.white : const Color(0xFFF9F9F9),
                      borderRadius: isLastRow
                          ? const BorderRadius.only(
                              bottomLeft: Radius.circular(12),
                              bottomRight: Radius.circular(12),
                            )
                          : BorderRadius.zero,
                    ),
                    child: Row(
                      children: List.generate(
                        bodyRows[rowIndex].length,
                        (colIndex) => Container(
                          width: 120,
                          padding: const EdgeInsets.all(16),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            border: Border(
                              right: BorderSide(
                                color: Colors.grey[200]!,
                                width: 1,
                              ),
                            ),
                          ),
                          child: Text(
                            bodyRows[rowIndex][colIndex],
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.grey[800],
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
